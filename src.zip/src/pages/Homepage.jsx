import React from 'react'
import Header from '../component/Header'
import Navbar from '../component/Navbar'
import Home from '../component/Home'
import Welcome from '../component/Welcome'
import Footer1 from '../component/Footer1'
import Footer from '../component/Footer'
import Service from '../component/Service'
import Notice from '../component/Notice'
import About from "../component/About"
import Testimonial from "../component/Testimonial"
import Contact from "../component/Contact"

function Homepage() {
  return (
    <div>
    <Header/>
    <Navbar/>
    <Home/>
    <Welcome/>
    <Service/>
    <About/>
    <Notice/>
    <Testimonial/>
    <Contact/>
    <Footer1/>
    <Footer/>
    </div>
  )
}

export default Homepage