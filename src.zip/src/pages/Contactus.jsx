import React from 'react'
import Header from '../component/Header'
import Navbar from '../component/Navbar'
import Contact from '../component/Contact'
import Footer from '../component/Footer'
import Footer1 from '../component/Footer1'

function Contactus() {
  return (
    <div>
    <Header/>
    <Navbar/>
    <Contact/>
    <Footer1/>
    <Footer/>
    </div>
  )
}

export default Contactus